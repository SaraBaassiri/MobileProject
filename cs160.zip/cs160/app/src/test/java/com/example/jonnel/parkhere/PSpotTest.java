package com.example.jonnel.parkhere;

import org.junit.Test;

import static junit.framework.Assert.assertFalse;
import static org.junit.Assert.*;

/**
 * Created by Daniel on 11/9/2017.
 */
public class PSpotTest
{

    @Test
    public void PSpotCheck() throws Exception {

}
}