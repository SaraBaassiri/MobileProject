Team O(k)
Sinjin Baglin (SJSUID:009032153)
Jonnel Alcantara (SJSUID:009101339)
Andrew Hon (SJSUID:009115678)
Daniel Vu (SJSUID:009254791)

We used Google's Firebase for our backend so there is no code to submit
for the server-side end of our project.

To Run:
In order to run the android application open the folder cs160 as an existing Android project.
Navigate to gradle on the right hand side and make sure to refresh all
gradle projects. Navigate to the Build drop down menu and make project.
Navigate to the Run drop down menu and click run 'app. Select a deployment
method whether that be using your own Android phone or one of Android Studio's 
many emulators. You should have successfully ran the application.

Another way to run:
We have provided a debug apk (app-debug) of our application. In a stand alone 
android emulator, such as Nox (https://www.bignox.com/),
enable root mode and drag and drop the apk into the emulator 
after launch and it should prompt you to install.
After installation launch the android application.
